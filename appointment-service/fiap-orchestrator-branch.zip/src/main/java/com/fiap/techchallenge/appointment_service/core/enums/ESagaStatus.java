package com.fiap.techchallenge.appointment_service.core.enums;

public enum ESagaStatus {
    SUCCESS, FAIL
}
